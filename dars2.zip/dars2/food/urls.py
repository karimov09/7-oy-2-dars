from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),  
    path('menu/', views.menu_list, name='menu_list'), 
    path('menu/create/', views.create_menu_item, name='create_menu_item'), 
    path('menu/update/<int:pk>/', views.update_menu_item, name='update_menu_item'),
    path('upload-image/', views.upload_image, name='upload_image'),  
]
