from django.shortcuts import render, redirect
from .forms import MenuItemForm, ImageUploadForm
from .models import MenuItem

def home(request):
    return render(request, 'home.html')

def menu_list(request):
    menu_items = MenuItem.objects.all()
    return render(request, 'menu_list.html', {'menu_items': menu_items})

def create_menu_item(request):
    if request.method == 'POST':
        form = MenuItemForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('menu_list')
    else:
        form = MenuItemForm()
    return render(request, 'create_menu_item.html', {'form': form})

def update_menu_item(request, pk):
    menu_item = MenuItem.objects.get(pk=pk)
    if request.method == 'POST':
        form = MenuItemForm(request.POST, request.FILES, instance=menu_item)
        if form.is_valid():
            form.save()
            return redirect('menu_list')
    else:
        form = MenuItemForm(instance=menu_item)
    return render(request, 'update_menu_item.html', {'form': form})

def upload_image(request):
    pass